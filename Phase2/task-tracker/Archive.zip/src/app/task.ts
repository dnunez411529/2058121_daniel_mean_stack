export class Task {
  constructor(
    public id: number,
    public name: string,
    public task: string,
    public deadLine: string
  ) {}
}
